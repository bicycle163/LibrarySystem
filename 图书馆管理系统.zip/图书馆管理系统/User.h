#pragma once

#include <iostream>
#include <string>
using namespace std;

class User
{
	private:
	    int role;//һ�ǹ���Ա�����Ƕ���
    public:
	    string account;
	    string password;
	    bool hasBorrowed; 
        User(int r) : role(r),hasBorrowed(false){}
        int getRole(); 
};

